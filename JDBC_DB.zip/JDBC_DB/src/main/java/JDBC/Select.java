package JDBC;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/select")
public class Select extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Select() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // 1. Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Create Connection
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/employee",
                    "root",
                    ""
            );

            // 3. SQL Query
            ps = con.prepareStatement("SELECT * FROM empData");
            rs = ps.executeQuery();

            // 4. HTML Output
            pw.println("<html><body>");
            pw.println("<h2>Employee Details</h2>");
            pw.println("<table border='1'>");
            pw.println("<tr>");
            pw.println("<th>Emp ID</th>");
            pw.println("<th>Emp Name</th>");
            pw.println("<th>Mobile No</th>");
            
            pw.println("</tr>");

            while (rs.next()) {
                pw.println("<tr>");
                pw.println("<td>" + rs.getInt(1) + "</td>");
                pw.println("<td>" + rs.getString(2) + "</td>");
                pw.println("<td>" + rs.getString(3) + "</td>");
                pw.println("<th><button type='submit' name = 'Delete'><a href='Delete'>Delete</a></button></th> ");
                pw.println("<th><button type='submit' name = 'Edit'><a href='Edit'>Edit</a></button></th> ");
                pw.println("</tr>");
            }

            pw.println("</table>");
            pw.println("</body></html>");

        } catch (Exception e) {
            pw.println("<h3>Error Occurred</h3>");
            e.printStackTrace(pw);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        pw.println("<button type='submit' name = 'index'><a href='index.jsp'>Home</a></button> ");
    }
}
